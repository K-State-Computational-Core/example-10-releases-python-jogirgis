"""Test package.

Author: Joseph Girgis
Version: 0.1
"""
